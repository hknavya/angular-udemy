import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { RouterModule } from "@angular/router";
import { AppRoutingModule } from "./app.routing";
import { FormsModule } from "@angular/forms";

import { AppComponent } from "./app.component";
import { IoComponent } from "./io/io.component";
import { FirstComponent } from "./io/first/first.component";
import { SecondComponent } from "./io/second/second.component";
import { FirstInnerComponent } from "./io/first/first-inner/first-inner.component";
import { SecondInnerComponent } from "./io/second/second-inner/second-inner.component";
import { OneComponent } from "./io/one/one.component";
import { TwoComponent } from "./io/two/two.component";
import { NestedIoComponent } from "./nested-io/nested-io.component";
import { NestedIoOneComponent } from "./nested-io/one/one.component";
import { NestedIoTwoComponent } from "./nested-io/two/two.component";
import { InnerOneComponent } from "./nested-io/one/inner-one/inner-one.component";
import { InnerTwoComponent } from "./nested-io/two/inner-two/inner-two.component";
import { GeneralComponent } from "./general/general.component";
import { ListComponent } from "./general/list/list.component";
import { BindingComponent } from "./binding/binding.component";
import { InbuiltDirectiveComponent } from "./inbuilt-directive/inbuilt-directive.component";
import { WelcomeComponent } from "./welcome/welcome.component";
import { ApplicationComponent } from "./application/application.component";
import { ShoppingListComponent } from "./application/shopping-list/shopping-list.component";
import { EditComponent } from "./application/shopping-list/edit/edit.component";
import { RecipesComponent } from "./application/recipes/recipes.component";
import { RecipeListComponent } from "./application/recipes/list/list.component";
import { RecipeListItemComponent } from "./application/recipes/list/item/item.component";
import { DetailComponent } from "./application/recipes/detail/detail.component";
import { HeaderComponent } from "./application/header/header.component";
import { ComponentCommunicationComponent } from "./component-communication/component-communication.component";
import { CompCommAddFormComponent } from "./component-communication/add-form/add-form.component";
import { CompCommDisplayFormComponent } from "./component-communication/display-form/display-form.component";
import { GameControlComponent } from "./assignment-one/game-control/game-control.component";
import { OddComponent } from "./assignment-one/odd/odd.component";
import { EvenComponent } from "./assignment-one/even/even.component";
import { DataBindingComponent } from "./assignment-one/data-binding.component";
import { DirectivesComponent } from "./directives/directives.component";
import { BasicDirective } from "./directives/basic/basic.directive";
import { BetterDirective } from "./directives/basic/better.directive";
import { DropdownDirective } from "./application/shared/dropdown.directive";
import { AngularServicesComponent } from "./angular-services/angular-services.component";
import { AccountComponent } from "./angular-services/account/account.component";
import { NewAccountComponent } from "./angular-services/new-account/new-account.component";
import { AssignmentServicesComponent } from "./assignment-services/assignment-services.component";
import { ActiveUsersComponent } from "./assignment-services/active-users/active-users.component";
import { InactiveUsersComponent } from "./assignment-services/inactive-users/inactive-users.component";

@NgModule({
	declarations: [
		AppComponent,
		IoComponent,
		FirstComponent,
		SecondComponent,
		FirstInnerComponent,
		SecondInnerComponent,
		OneComponent,
		TwoComponent,
		NestedIoComponent,
		NestedIoOneComponent,
		NestedIoTwoComponent,
		InnerOneComponent,
		InnerTwoComponent,
		GeneralComponent,
		ListComponent,
		BindingComponent,
		InbuiltDirectiveComponent,
		WelcomeComponent,
		ApplicationComponent,
		ShoppingListComponent,
		EditComponent,
		RecipesComponent,
		RecipeListComponent,
		RecipeListItemComponent,
		DetailComponent,
		HeaderComponent,
		ComponentCommunicationComponent,
		CompCommAddFormComponent,
		CompCommDisplayFormComponent,
		GameControlComponent,
		OddComponent,
		EvenComponent,
		DataBindingComponent,
		DirectivesComponent,
		BasicDirective,
		BetterDirective,
		DropdownDirective,
		AngularServicesComponent,
		AccountComponent,
		NewAccountComponent,
		AssignmentServicesComponent,
		ActiveUsersComponent,
		InactiveUsersComponent
	],
	imports: [
		BrowserModule,
		AppRoutingModule,
		BrowserAnimationsModule,
		FormsModule
	],
	providers: [],
	bootstrap: [AppComponent]
})
export class AppModule {}
