import { Component, OnInit, Output, EventEmitter } from "@angular/core";
import { Recipe } from "../recipe.model";

@Component({
	selector: "app-recipes-list",
	templateUrl: "./list.component.html"
})
export class RecipeListComponent implements OnInit {
	@Output() recipeList = new EventEmitter<any>();

	recipes: Recipe[] = [
		new Recipe(
			"Pasta",
			"Pasta is so hot and yummy!!",
			"http://cdn1.brandwiki.today/sites/48/2015/04/pasta-1200x720.jpg"
		),
		new Recipe(
			"Donuts",
			"Donuts is a box of happiness!!",
			"http://www.trbimg.com/img-5a4ffb42/turbine/sns-dailymeal-1865506-hero-donuts-edit-20180105/1600/1600x900"
		)
	];
	constructor() {}

	onClickRecipe(recipe) {
		console.log(recipe, "recipeListComponent");
		this.recipeList.emit(recipe);
	}

	ngOnInit() {}
}
