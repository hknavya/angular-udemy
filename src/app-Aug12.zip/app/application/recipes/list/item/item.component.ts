import { Component, OnInit, Input, Output, EventEmitter } from "@angular/core";
import { Recipe } from "../../recipe.model";

@Component({
	selector: "app-recipes-list-item",
	templateUrl: "./item.component.html"
})
export class RecipeListItemComponent implements OnInit {
	@Input() recipe: Recipe;
	@Output() onRecipeItem = new EventEmitter<any>();
	constructor() {}

	recipeItem() {
		this.onRecipeItem.emit(this.recipe);
	}

	ngOnInit() {
		console.log(this.recipe, "recipe");
	}
}
