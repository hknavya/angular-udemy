import { Component, OnInit, Input } from "@angular/core";
import { Recipe } from "../recipe.model";

@Component({
	selector: "app-recipes-detail",
	templateUrl: "./detail.component.html"
})
export class DetailComponent implements OnInit {
	@Input() recipe;
	constructor() {}

	ngOnInit() {
		// console.log(recipe, "recipeDetail");
	}
}
