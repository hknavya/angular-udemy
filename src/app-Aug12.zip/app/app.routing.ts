import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { IoComponent } from "./io/io.component";
import { NestedIoComponent } from "./nested-io/nested-io.component";
import { GeneralComponent } from "./general/general.component";
import { WelcomeComponent } from "./welcome/welcome.component";
import { ApplicationComponent } from "./application/application.component";
import { ComponentCommunicationComponent } from "./component-communication/component-communication.component";
import { GameControlComponent } from "./assignment-one/game-control/game-control.component";
import { OddComponent } from "./assignment-one/odd/odd.component";
import { EvenComponent } from "./assignment-one/even/even.component";
import { DataBindingComponent } from "./assignment-one/data-binding.component";
import { DirectivesComponent } from "./directives/directives.component";
import { AngularServicesComponent } from "./angular-services/angular-services.component";
import { AssignmentServicesComponent } from "./assignment-services/assignment-services.component";

const routes: Routes = [
	{
		path: "",
		redirectTo: "/welcome",
		pathMatch: "full"
	},
	{ path: "io", component: IoComponent },
	{ path: "nested-io", component: NestedIoComponent },
	{ path: "general", component: GeneralComponent },
	{ path: "welcome", component: WelcomeComponent },
	{ path: "application", component: ApplicationComponent },
	{
		path: "component-communication",
		component: ComponentCommunicationComponent
	},
	{ path: "assignment-data-binding", component: DataBindingComponent },
	{ path: "directives", component: DirectivesComponent },
	{ path: "ang-services", component: AngularServicesComponent },
	{ path: "assignment-services", component: AssignmentServicesComponent }
];

@NgModule({
	imports: [RouterModule.forRoot(routes)],
	exports: [RouterModule]
})
export class AppRoutingModule {}
